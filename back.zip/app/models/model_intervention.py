# 📦 MODELE INTERVENTION SQLALCHEMY
# Fichier : app/models/model_intervention.py

from sqlalchemy import Column, Integer, String, Text, ForeignKey, DateTime, Table
from sqlalchemy.orm import relationship
from datetime import datetime
from app.database import Base

# Table de liaison produits/interventions
intervention_produits = Table(
    "intervention_produits",
    Base.metadata,
    Column("intervention_id", Integer, ForeignKey("interventions.id")),
    Column("produit_id", Integer, ForeignKey("produits.id")),
    Column("enterprise_id", Integer, ForeignKey("enterprises.id"), index=True),
)

class Intervention(Base):
    __tablename__ = "interventions"

    id = Column(Integer, primary_key=True, index=True)
    client_id = Column(Integer, ForeignKey("clients.id"), nullable=False)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)  # utilisateur principal (technicien)
    enterprise_id = Column(Integer, ForeignKey("enterprises.id"), nullable=True, index=True)
    description = Column(Text, nullable=True)
    statut = Column(String, default="en cours")  # ex: en cours, terminé, annulé
    date_intervention = Column(DateTime, default=datetime.utcnow)
    produit_ex = Column(String, nullable=True)
    caracteristique_ex = Column(Text, nullable=True)
    commentaire_ex = Column(Text, nullable=True)
    

    # Relations
    client = relationship("Client", backref="interventions")
    user = relationship("User", backref="interventions")
    produits = relationship("Produit", secondary=intervention_produits, backref="interventions")

    def __repr__(self):
        return f"<Intervention client={self.client_id} employe={self.employe_id}>"
