# 📦 MODELES POUR FACTURATION
# Fichier : app/models/model_facture.py

from sqlalchemy import Column, ForeignKey, Integer, String, Float, DateTime, ForeignKey, Enum, Text
from sqlalchemy.orm import relationship
from datetime import datetime
from enum import Enum as PyEnum
from app.database import Base

class TypeFacture(PyEnum):
    achat = "achat"
    vente = "vente"
    devis = "devis"
    proforma = "proforma"

class Facture(Base):
    __tablename__ = "factures"

    id = Column(Integer, primary_key=True, index=True)
    type = Column(Enum(TypeFacture), nullable=False)
    client_id = Column(Integer, ForeignKey("clients.id"), nullable=True)
    fournisseur_id = Column(Integer, ForeignKey("fournisseurs.id"), nullable=True)
    # depot_id = Column(Integer, ForeignKey("depots.id"), nullable=True)
    date_creation = Column(DateTime, default=datetime.utcnow)
    technical_created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    statut = Column(String, default="en attente")  # ex: brouillon, envoyé, payé, annulé
    remarques = Column(Text, nullable=True)
    total_ht = Column(Float, default=0.0)
    total_ttc = Column(Float, default=0.0)
    tva = Column(Float, default=0.0)
    devise = Column(String, default="FCFA")
    
    commande_achat_id = Column(Integer, ForeignKey("commandes_achats.id"), nullable=True)
    commande_id = Column(Integer, ForeignKey("commandes_ventes.id"), nullable=True)
    commande = relationship("CommandeVente")

    # depot = relationship("Depot", back_populates="facture", uselist=False)
    
    user_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    enterprise_id = Column(Integer, ForeignKey("enterprises.id"), nullable=True, index=True)
    enterprise = relationship("Enterprise", foreign_keys=[enterprise_id])
    user = relationship("User", foreign_keys=[user_id], backref="factures")

    sub_user_id = Column(Integer, ForeignKey("sub_users.id"), nullable=True)
    sub_user = relationship("SubUser", foreign_keys=[sub_user_id])

    issued_by_user_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    issued_by_sub_user_id = Column(Integer, ForeignKey("sub_users.id"), nullable=True)
    issuer_name_snapshot = Column(String(160), nullable=True)
    issuer_role_snapshot = Column(String(80), nullable=True)
    invoice_color_snapshot = Column(String(16), nullable=True)
    simple_template_snapshot = Column(String(48), nullable=True)
    professional_template_snapshot = Column(String(48), nullable=True)


    client = relationship("Client", back_populates="factures")

    fournisseur = relationship("Fournisseur", back_populates="factures")

    lignes = relationship("LigneFacture", back_populates="facture", cascade="all, delete")
    paiements = relationship("Paiement", back_populates="facture", cascade="all, delete")

class LigneFacture(Base):
    __tablename__ = "lignes_facture"

    id = Column(Integer, primary_key=True, index=True)
    facture_id = Column(Integer, ForeignKey("factures.id"))
    produit_id = Column(Integer, ForeignKey("produits.id"))
    description = Column(String, nullable=False)
    # Copie modifiable uniquement pour cette facture. La fiche produit reste intacte.
    caracteristiques_snapshot = Column(Text, nullable=True)
    quantite = Column(Integer, nullable=False)
    prix_unitaire = Column(Float, nullable=False)
    # Coût figé au moment de la facturation pour les indicateurs de marge.
    cout_achat_unitaire = Column(Float, nullable=False, default=0)
    total_ligne = Column(Float, nullable=False)
    
    user_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    enterprise_id = Column(Integer, ForeignKey("enterprises.id"), nullable=True, index=True)
    user = relationship("User", backref="lignes_facture")



    facture = relationship("Facture", back_populates="lignes")
    produit = relationship("Produit")
