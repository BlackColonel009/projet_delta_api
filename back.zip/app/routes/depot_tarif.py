from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from typing import List, Optional
from app.database import get_db
from app.models.model_depot_tarif import DepotTarif
from app.models.model_depot_service import DepotService
from app.schemas.depot_tarif_schema import DepotTarifCreate, DepotTarifOut
from app.utils.security import get_current_user
from app.utils.permissions import check_role
from app.schemas.user_schema import RoleEnum
from app.utils.logger import log_action
from sqlalchemy.orm import joinedload
from app.services.depot_pricing_service import normalize_pricing_mode
from app.services.enterprise_service import actor_enterprise_id, actor_owner_id, enterprise_scope_filter

router = APIRouter(prefix="/depot-tarifs", tags=["Dépôt - Tarifs"])

# ➕ Créer un tarif pour un service
@router.post("/", response_model=DepotTarifOut)
def create_tarif(
    data: DepotTarifCreate,
    db: Session = Depends(get_db),
    current_user=Depends(check_role([RoleEnum.admin]))
):
    parent_user_id = actor_owner_id(current_user)
    service = db.query(DepotService).filter(
        DepotService.id == data.service_id,
        enterprise_scope_filter(DepotService, current_user),
    ).first()
    if not service:
        raise HTTPException(status_code=404, detail="Service introuvable ou non autorisé.")
    if normalize_pricing_mode(service.mode_tarification) != data.mode_tarification:
        raise HTTPException(
            status_code=400,
            detail="Le mode du tarif doit correspondre au mode du service.",
        )

    tarif = DepotTarif(
        **data.model_dump(exclude={"service_nom"}),
        user_id=parent_user_id,
        enterprise_id=actor_enterprise_id(current_user),
    )
    db.add(tarif)
    db.commit()
    db.refresh(tarif)

    # Recharger avec relation service pour que service_nom fonctionne
    tarif = db.query(DepotTarif).options(joinedload(DepotTarif.service)).get(tarif.id)

    log_action(
        db=db,
        current_user=current_user,
        action="Création tarif dépôt",
        type_entite="depot_tarif",
        entite_id=tarif.id,
        details=f"Tarif '{tarif.nom_tarif}' créé pour service '{service.nom}'"
    )
    return tarif

# 📄 Lister les tarifs d'un service
@router.get("/", response_model=List[DepotTarifOut])
def list_tarifs(
    service_id: Optional[int] = Query(None),
    db: Session = Depends(get_db),
    current_user=Depends(check_role([RoleEnum.admin, RoleEnum.gestionnaire_stock]))
):
    query = db.query(DepotTarif).join(DepotService).filter(
        enterprise_scope_filter(DepotTarif, current_user)
    )

    if service_id:
        query = query.filter(DepotTarif.service_id == service_id)

    tarifs = query.order_by(DepotTarif.nom_tarif.asc()).all()

    result = [
        DepotTarifOut(
            id=tarif.id,
            nom_tarif=tarif.nom_tarif,
            mode_tarification=tarif.mode_tarification,
            tarif_unitaire=tarif.tarif_unitaire,
            tarif_par_minute=tarif.tarif_par_minute,
            service_id=tarif.service_id,
            service_nom=tarif.service.nom if tarif.service else "Inconnu",
            actif=tarif.actif,
            date_creation=tarif.date_creation
        )
        for tarif in tarifs
    ]
    return result


# 📄 Update des tarifs
@router.put("/{tarif_id}", response_model=DepotTarifOut)
def update_tarif(
    tarif_id: int,
    data: DepotTarifCreate,
    db: Session = Depends(get_db),
    current_user=Depends(check_role([RoleEnum.admin]))
):
    tarif = db.query(DepotTarif).join(DepotService).filter(
        DepotTarif.id == tarif_id,
        enterprise_scope_filter(DepotTarif, current_user),
    ).first()
    if not tarif:
        raise HTTPException(status_code=404, detail="Tarif introuvable ou non autorisé.")

    target_service = db.query(DepotService).filter(
        DepotService.id == data.service_id,
        enterprise_scope_filter(DepotService, current_user),
    ).first()
    if not target_service:
        raise HTTPException(
            status_code=404,
            detail="Service introuvable ou non autorisé.",
        )
    if (
        normalize_pricing_mode(target_service.mode_tarification)
        != data.mode_tarification
    ):
        raise HTTPException(
            status_code=400,
            detail="Le mode du tarif doit correspondre au mode du service.",
        )

    for key, value in data.model_dump().items():
        setattr(tarif, key, value)

    db.commit()
    db.refresh(tarif)

    log_action(
        db=db,
        current_user=current_user,
        action="Modification tarif dépôt",
        type_entite="depot_tarif",
        entite_id=tarif.id,
        details=f"Tarif modifié : {tarif.nom_tarif}"
    )
    return tarif

