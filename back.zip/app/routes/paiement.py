from datetime import datetime
from datetime import datetime, timedelta

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.core.mail import send_email_message
from app.email.branded_templates import payment_confirmation_email
from app.utils.i18n import language_of, translated
from app.database import get_db
from app.models.model_commande import CommandeVente
from app.models.model_clientfollowup import ClientFollowup, FollowupStatus
from app.models.model_paiement import Paiement
from app.models.model_facture import Facture
from app.models.model_produit import Produit
from app.models.model_unite_produit import UniteProduit
from app.schemas.paiement_schema import PaiementCreate
from app.utils.logger import log_action
from app.utils.security import get_current_user
from app.utils.permissions import check_role
from app.schemas.user_schema import RoleEnum
from app.models.model_user import User
from sqlalchemy import func
from app.services.enterprise_service import (
    actor_enterprise_id,
    actor_owner_id,
    enterprise_scope_filter,
)

router = APIRouter(prefix="/paiements", tags=["Paiements"])


# ➕ Créer un paiement (admin + caissier)
@router.post("/", response_model=dict)
async def create_paiement(
    data: PaiementCreate,
    db: Session = Depends(get_db),
    current_user=Depends(check_role([RoleEnum.admin, RoleEnum.caissier]))
):
    parent_user_id = actor_owner_id(current_user)
    enterprise_id = actor_enterprise_id(current_user)
    # 🔎 Récupérer la facture
    facture = db.query(Facture).filter(
        Facture.id == data.facture_id,
        enterprise_scope_filter(Facture, current_user),
    ).with_for_update().first()
    if not facture:
        raise HTTPException(status_code=404, detail="Facture non trouvée")
    if facture.statut == "annulée":
        raise HTTPException(
            status_code=409,
            detail="Aucun paiement ne peut être ajouté à une facture annulée.",
        )

    total_avant = db.query(func.sum(Paiement.montant)).filter(
        Paiement.facture_id == facture.id,
        Paiement.enterprise_id == facture.enterprise_id,
    ).scalar() or 0.0
    reste = max(float(facture.total_ttc or 0) - float(total_avant), 0.0)
    if data.montant > reste + 0.000001:
        raise HTTPException(
            status_code=409,
            detail=f"Le paiement dépasse le reste dû ({reste:.2f}).",
        )

    # ➕ Enregistrer le paiement
    paiement = Paiement(
        **data.model_dump(),
        user_id=parent_user_id,
        enterprise_id=enterprise_id,
    )
    db.add(paiement)
    db.flush()

    # 🧮 Total payé à ce jour
    total_paye = float(total_avant) + data.montant
    
    

    # 🔁 Si facture totalement payée
    if total_paye >= facture.total_ttc:
        facture.statut = "payée"

        if facture.type.value == "vente":
            commande = db.query(CommandeVente).filter(
                CommandeVente.id == facture.commande_id,
                CommandeVente.enterprise_id == facture.enterprise_id,
            ).first()
            if commande:
                
                commande.statut = "validée"
                followup = db.query(ClientFollowup).filter(
                    ClientFollowup.commande_id == commande.id,
                    ClientFollowup.enterprise_id == facture.enterprise_id,
                    ClientFollowup.type_followup == "relance_paiement",
                ).first()
                if followup:
                    followup.type_followup = "fidélisation"
                    followup.statut = FollowupStatus.en_attente
                    followup.payment_reminder_enabled = False
                    thank_you_delay = getattr(
                        facture.client,
                        "followup_thank_you_delay_days",
                        1,
                    )
                    followup.date_prochain_envoi = datetime.utcnow() + timedelta(
                        days=thank_you_delay
                    )
                # ✅ Marquer toutes les unités liées comme vendues
                unites = db.query(UniteProduit).filter(
                    UniteProduit.commande_vente_id == commande.id,
                    UniteProduit.enterprise_id == facture.enterprise_id,
                    UniteProduit.statut.in_(["en cours", "disponible"])
                ).with_for_update().all()

                for unite in unites:
                    unite.statut = "vendu"
                    unite.date_modification = datetime.utcnow()

        elif facture.type.value == "achat":
            from app.models.model_commande import CommandeAchat
            commande = db.query(CommandeAchat).filter(
                CommandeAchat.id == facture.commande_achat_id,
                CommandeAchat.enterprise_id == facture.enterprise_id,
            ).first()
            if commande:
                commande.statut = "validée"
                
    elif total_paye > 0:
        facture.statut = "partielle"
    else:
        facture.statut = "non payée"

    db.commit()
    db.refresh(paiement)

     # 📧 Envoi de mail au client (si vente uniquement et email présent)
    if facture.client and facture.client.email:
        try:
            await envoyer_mail_confirmation_paiement(facture.client, facture, paiement, total_paye)
        except Exception as e:
            print("Erreur lors de l'envoi de l'email de paiement :", e)


    # 📝 Log global du paiement
    log_action(
        db=db,
        current_user=current_user,
        action="Ajout paiement",
        type_entite="paiement",
        entite_id=paiement.id,
        details=f"Paiement de {paiement.montant:.2f} € pour Facture #{facture.id} via {paiement.moyen_paiement}"
    )

    return {"message": f"Paiement enregistré sur la facture #{facture.id}"}

async def envoyer_mail_confirmation_paiement(client, facture, paiement, total_paye):
    language = language_of(facture.user)
    tr = lambda fr, en: translated(language, fr, en)
    sujet = tr(f"Confirmation de paiement - Facture #{facture.id}", f"Payment confirmation - Invoice #{facture.id}")
    devise = facture.user.devise if hasattr(facture, "user") else ""
    paid = min(float(total_paye or 0), float(facture.total_ttc or 0))
    balance = max(float(facture.total_ttc or 0) - paid, 0.0)
    is_settled = balance <= 0.01 or facture.statut == "payée"
    contenu = payment_confirmation_email(
        user=facture.user,
        client_name=client.nom,
        invoice_id=facture.id,
        invoice_date=facture.date_creation,
        payment_amount=paiement.montant,
        payment_method=paiement.moyen_paiement,
        total=facture.total_ttc,
        paid=paid,
        balance=balance,
        currency=devise,
        is_settled=is_settled,
    )

    await send_email_message(
        to_email=client.email,
        subject=sujet,
        body=contenu,
        reply_to=facture.user.email if facture.user else None,
        is_html=True,
    )



# 📋 Lister les paiements d'une facture (admin, caissier, comptable)
@router.get("/{facture_id}", response_model=list)
def list_paiements_for_facture(
    facture_id: int,
    db: Session = Depends(get_db),
    current_user=Depends(check_role([RoleEnum.admin, RoleEnum.caissier, RoleEnum.comptable]))
):
    facture = db.query(Facture).filter(
        Facture.id == facture_id,
        enterprise_scope_filter(Facture, current_user),
    ).first()
    if not facture:
        raise HTTPException(status_code=404, detail="Facture non trouvée")
    # La facture vient d'être cloisonnée par entreprise ci-dessus. Filtrer une
    # seconde fois sur Paiement.user_id masquait les paiements historiques
    # créés avant l'ajout de cette colonne (user_id NULL), bien qu'ils soient
    # correctement rattachés à cette facture.
    paiements = db.query(Paiement).filter(
        Paiement.facture_id == facture.id,
        Paiement.enterprise_id == facture.enterprise_id,
    ).order_by(Paiement.date_paiement.desc(), Paiement.id.desc()).all()
    return [
        {
            "id": p.id,
            "montant": p.montant,
            "date_paiement": p.date_paiement.strftime('%d/%m/%Y'),
            "moyen_paiement": p.moyen_paiement
        }
        for p in paiements
    ]
#supression paîements
@router.delete("/{paiement_id}", response_model=dict)
def delete_paiement(
    paiement_id: int,
    db: Session = Depends(get_db),
    current_user=Depends(check_role([RoleEnum.admin, RoleEnum.caissier]))
):
    paiement = db.query(Paiement).join(Facture).filter(
        Paiement.id == paiement_id,
        enterprise_scope_filter(Facture, current_user),
    ).with_for_update().first()
    if not paiement:
        raise HTTPException(status_code=404, detail="Paiement non trouvé")

    facture = paiement.facture

    db.delete(paiement)
    db.flush()

    # 🔁 Recalcul du statut de la facture après suppression
    total_paye = db.query(func.sum(Paiement.montant)).filter(
        Paiement.facture_id == facture.id,
        Paiement.enterprise_id == facture.enterprise_id,
    ).scalar() or 0.0

    if total_paye >= facture.total_ttc:
        facture.statut = "payée"
    elif total_paye > 0:
        facture.statut = "partielle"
    else:
        facture.statut = "non payée"

    # Une suppression peut rouvrir une facture auparavant soldee. La relance
    # de paiement doit alors reprendre, au lieu de laisser le suivi dans le
    # scenario de fidelisation.
    if total_paye < facture.total_ttc and facture.type.value == "vente":
        commande_ouverte = db.query(CommandeVente).filter(
            CommandeVente.id == facture.commande_id,
            CommandeVente.enterprise_id == facture.enterprise_id,
        ).first()
        if commande_ouverte:
            commande_ouverte.statut = "en_attente"
            followup = db.query(ClientFollowup).filter(
                ClientFollowup.commande_id == commande_ouverte.id,
                ClientFollowup.enterprise_id == facture.enterprise_id,
            ).first()
            if followup:
                followup.type_followup = "relance_paiement"
                followup.statut = FollowupStatus.en_attente
                followup.payment_reminder_enabled = True
                delay = followup.delai_avant_relance or 2
                followup.date_prochain_envoi = datetime.utcnow() + timedelta(
                    days=delay
                )

    # Sans aucun paiement, les unites redeviennent disponibles pour la vente.
    if total_paye <= 0:
        if facture.type.value == "vente":
            commande = db.query(CommandeVente).filter(
                CommandeVente.id == facture.commande_id,
                CommandeVente.enterprise_id == facture.enterprise_id,
            ).first()
            if commande:
                unites = db.query(UniteProduit).filter(
                    UniteProduit.commande_vente_id == commande.id,
                    UniteProduit.enterprise_id == facture.enterprise_id,
                    UniteProduit.statut.in_(["en cours", "vendu"])
                ).all()

                for unite in unites:
                    unite.statut = "en cours"
                    unite.date_modification = datetime.utcnow()

                    log_action(
                        db=db,
                        current_user=current_user,
                        action="Réinitialisation unité",
                        type_entite="unite_produit",
                        entite_id=unite.id,
                        details=f"Unité {unite.tracabilite} remise à en cours (annulation paiement)"
                    )

    db.commit()

    # 📝 Log global
    log_action(
        db=db,
        current_user=current_user,
        action="Suppression paiement",
        type_entite="paiement",
        entite_id=paiement_id,
        details=f"Paiement supprimé pour Facture #{facture.id} — Nouveau statut : {facture.statut}"
    )

    return {"message": "Paiement supprimé avec succès."}

